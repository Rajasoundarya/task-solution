#Create Multiple CSV from a single file grouped by columnA

  I would like to provide two solutions.

1. The solution 1 has only standard package like fs and the others are user defined functions.

2. The solution 2 has packages to do all the work which makes the coding less.
